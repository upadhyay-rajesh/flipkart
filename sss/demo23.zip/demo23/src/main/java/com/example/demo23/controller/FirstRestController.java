package com.example.demo23.controller;

import com.example.demo23.entity.Employee;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
public class FirstRestController {

    @RequestMapping("empList")
    public List<Employee> getList(){
        List<Employee> ee=new ArrayList<Employee>();
        Employee e1=new Employee();
        e1.setEmployee_id(1);
        e1.setName("Rajesh");
        e1.setAddress("Bangalore");

        Employee e2=new Employee();
        e2.setEmployee_id(2);
        e2.setName("Tufail");
        e2.setAddress("Bangalore1");

        ee.add(e1);
        ee.add(e2);
        return ee;
    }
}
