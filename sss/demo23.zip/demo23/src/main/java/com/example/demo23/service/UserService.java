package com.example.demo23.service;

import java.util.List;

public interface UserService {
	public List getUserDetails();
}
