package com.example.demo23.dao;

import java.util.List;

public interface UserDao {
	public List getUserDetails();
}
